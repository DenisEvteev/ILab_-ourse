# Laba1.1.4
The programm creates the massiv with data with the number of particles for 40 seconds and count the error
